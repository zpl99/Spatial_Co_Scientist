import os

model = "azure/" + os.environ["OPENAI_API_DEPLOYMENT"]
